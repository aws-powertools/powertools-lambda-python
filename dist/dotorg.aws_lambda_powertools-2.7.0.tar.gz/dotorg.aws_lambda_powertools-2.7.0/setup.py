from setuptools import setup, find_namespace_packages

setup(name='dotorg.aws_lambda_powertools',
      version='2.7.0',
      description='Fork of awslabs/aws_lambda_powertools',
      url='git@https://github.com/dotorg-tech/aws-lambda-powertools-python.git',
      author='Richard B',
      author_email='richard@dotorg.io',
      license='MIT',
      include_package_data=True,
      packages=find_namespace_packages(include=['dotorg.aws_lambda_powertools', 'dotorg.aws_lambda_powertools.*']),
      zip_safe=False)
